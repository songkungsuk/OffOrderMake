package org.techtown.test;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class MenuActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ProductAdapter adapter;
    public static final int pay = 103;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        //객체 리스트화 시켜서
        ArrayList<Product> beverage2 = new ArrayList<Product>();
        beverage2.add(new Product("음료수1", "스타벅스", 2000, R.drawable.strawberry));
        beverage2.add(new Product("음료수2", "스타벅스", 3000, R.drawable.mango_banana));
        beverage2.add(new Product("음료수3", "스타벅스", 4000, R.drawable.mango_fruit));

//        객체 배열처리 연습
//        Product[] beverage = new Product[5];
//        beverage[0] = new Product("음료수1", "스타벅스", 2000, R.drawable.strawberry);
//        beverage[1] = new Product("2", "스타벅스", 3300, R.drawable.strawberry);
//        beverage[2] = new Product("3", "스타벅스", 4400, R.drawable.strawberry);
//        beverage[3] = new Product("4", "스타벅스", 5500, R.drawable.strawberry);
//        beverage[4] = new Product("5", "스타벅스", 6700, R.drawable.strawberry);



        Button button = findViewById(R.id.button6); //결제하기 버튼 객체 생성
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), paypage.class);
                startActivityForResult(intent, pay);
            }
        });
        recyclerView = findViewById(R.id.recycleView);

        GridLayoutManager layoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new ProductAdapter();

        adapter.addItem(new Product("망고 패션 프루트 블랜디드", "스타벅스", 5500, R.drawable.mango_fruit));
        adapter.addItem(new Product("딸기 딜라이트 요거트 블랜디드", "스타벅스", 5700, R.drawable.strawberry));
        adapter.addItem(new Product("방고 바나나 블랜디드", "스타벅스", 5300, R.drawable.mango_banana));
        adapter.addItem(new Product("제주 감귤 당근 스노잉 블랜디드", "스타벅스", 5500, R.drawable.jeju));

        recyclerView.setAdapter(adapter);


        Button blended = findViewById(R.id.blended);
        blended.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adapter.init_item();

                for(int i=0; i< beverage2.size(); i++)
                {
                    adapter.addItem(beverage2.get(i));
                }

                recyclerView.setAdapter(adapter);

            }
        });


        adapter.setOnItemClickListener(new OnProductItemClickListener() {
            @Override
            public void onItemClick(ProductAdapter.ViewHolder holder, View view, int position) {
                Product item = adapter.getItem(position);
                if(item.getPrice() > 0){
                    Intent intent = new Intent(getApplicationContext(), productselect.class);
                    intent.putExtra("name", item.getName());
                    intent.putExtra("price", Integer.toString(item.getPrice()));
                    intent.putExtra("photo", Integer.toString(item.getImageRes()));
                    intent.putExtra("manufacturer", item.getManufacturer());
                    Toast.makeText(getApplicationContext(), "선택된 제품 : " + item.getName(), Toast.LENGTH_SHORT).show();
                    startActivity(intent);
                }

            }
        });

    }


}