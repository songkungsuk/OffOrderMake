package org.techtown.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class dialog_url extends AppCompatActivity {

    public static final int pay = 102;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialog_url);

        Button button3 = findViewById(R.id.button3); //확인버튼
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();

                EditText url = findViewById(R.id.url);
                String value = url.getText().toString();
                intent.putExtra("money",value);
                setResult(pay, intent);
                finish();
            }
        });
        Button button4 = findViewById(R.id.button4); //취소버튼
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                EditText url = findViewById(R.id.url);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }
}