package org.techtown.test;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class productselect extends AppCompatActivity {
    private int img;
    String total; //상품선택할때 전체가격
    int amount; // 상품수량
    int price2; // 상품가격
    int shot = 0; // 샷
    boolean ice = true; // 얼음 유무

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productselect);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        Intent intent = getIntent();
        ice_effect();

        ImageView photo = (ImageView) findViewById(R.id.product_image);
        TextView name = (TextView) findViewById(R.id.name);
        TextView price = (TextView) findViewById(R.id.price);
        String manufacturer = intent.getStringExtra("manufacturer");

        img = Integer.parseInt(intent.getStringExtra("photo"));
        photo.setImageResource(img);
        name.setText(intent.getStringExtra("name"));
        price.setText(intent.getStringExtra("price"));

        //수량
        TextView count2 = findViewById(R.id.count2);
        amount = Integer.parseInt(count2.getText().toString());
        //가격
        price2 = Integer.parseInt(price.getText().toString());
        //합계
        total = Integer.toString(amount * price2 );

        TextView result = findViewById(R.id.result);
        result.setText(total);
        //확인 버튼
        Button Ok_button = findViewById(R.id.ok);
        Ok_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(getApplicationContext(), MenuActivity.class);
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent2.putExtra("amount", Integer.toString(amount));

                startActivity(intent2);
                Toast.makeText(getApplicationContext(), "구매상품에 추가되셧습니다", Toast.LENGTH_SHORT).show();
            }
        });
        // 취소버튼
        Button cancel_button = findViewById(R.id.cancel);
        cancel_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(getApplicationContext(), MenuActivity.class);
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent2);
                Toast.makeText(getApplicationContext(), "취소", Toast.LENGTH_SHORT).show();
            }
        });
        //plus and minus button 수량
        ImageButton plus1 = findViewById(R.id.plus1);
        plus1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView count2 = findViewById(R.id.count2);
                amount++;
                count2.setText(Integer.toString(amount));
                total = Integer.toString(amount * price2 );
                TextView result = findViewById(R.id.result);
                result.setText(total);

            }
        });
        ImageButton minus1 = findViewById(R.id.minus1);
        minus1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView count2 = findViewById(R.id.count2);
                if(amount > 1){
                    amount--;
                    count2.setText(Integer.toString(amount));
                    total = Integer.toString(amount * price2 );
                    TextView result = findViewById(R.id.result);
                    result.setText(total);
                }else{
                    Toast.makeText(getApplicationContext(), "1 이하로는 할 수 없습니다", Toast.LENGTH_SHORT).show();
                }

            }
        });
        // plus minus button 샷추가
        ImageButton plus2 = findViewById(R.id.plus2);
        plus2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                shot++;
                shot_text_set();
            }
        });
        ImageButton minus2 = findViewById(R.id.minus2);
        minus2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                shot--;
                shot_text_set();
            }
        });

        //얼음 on / off
        Button on = findViewById(R.id.on);
        Button off = findViewById(R.id.off);
        on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ice = true;
                ice_effect();
            }
        });
        off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ice = false;
                ice_effect();
            }
        });
    }
    public void shot_text_set(){
        TextView count3 = findViewById(R.id.count3); // 샷추가
        String none_shot = "없음";
        if (shot > 0){
            count3.setText(Integer.toString(shot));
        }else{
            count3.setText(none_shot);
        }
    }

    public void ice_effect(){ //얼음 있으면 효과줌
        Button on = findViewById(R.id.on);
        Button off = findViewById(R.id.off);

        if (ice == true){
            on.setBackgroundColor(Color.CYAN);
            off.setBackgroundColor(0);
        }else {
            off.setBackgroundColor(Color.RED);
            on.setBackgroundColor(0);
        }
    }
}