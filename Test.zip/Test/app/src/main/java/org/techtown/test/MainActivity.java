package org.techtown.test;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.yanzhenjie.permission.Action;
import com.yanzhenjie.permission.AndPermission;
import com.yanzhenjie.permission.runtime.Permission;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class MainActivity extends AppCompatActivity {
    public static final int NUMBER_ORDER = 100; //메뉴화면으로 들어가는 버튼 요청번호

    Intent intent;
    ImageButton sttBtn; //음성인식 버튼
    TextView textView; // 음성인식 값뽑아낼 텍스트뷰
    MainActivity mainActivity;
    final int PERMISSION = 1; // 마이크 권한
    final int CAMERA_PERMISSION = 2; //카메라 권한

    public void deep_Link(){ //딥링크 메소드
        String DEFAULT_PATH = "order://off_order/";
        Intent intent = getIntent();
        String action = intent.getAction();
        String data = intent.getDataString();

        if (Intent.ACTION_VIEW.equalsIgnoreCase(action) && data != null) {
            if (data.startsWith(DEFAULT_PATH)) {
                String param = data.replace(DEFAULT_PATH, "");

                if (param.equals("first_menu")){
                    Intent intent1 = new Intent(getApplicationContext(), MenuActivity.class);
                    startActivityForResult(intent1, NUMBER_ORDER);
                }
            }
        }
    }
//    public void Permission_Check(){
//        if (ContextCompat.checkSelfPermission(mainActivity, Manifest.permission.READ_CONTACTS)!= PackageManager.PERMISSION_GRANTED) {
//            //권한이 부여되면 PERMISSION_GRANTED 거부되면 PERMISSION_DENIED 리턴
//
////권한 요청 할 필요가 있는가?
//            if (ActivityCompat.shouldShowRequestPermissionRationale(mainActivity, Manifest.permission.READ_CONTACTS)) {
//
//                // Show an expanation to the user *asynchronously* -- don't block
//                // this thread waiting for the user's response! After the user
//                // sees the explanation, try again to request the permission.
//
//            } else {
//                //권한 요청을 해야할 필요가 있는 경우(사용자가 DONT ASK ME AGIAN CHECK + DENY 선택)
//
//                ActivityCompat.requestPermissions(mainActivity, new String[]{Manifest.permission.READ_CONTACTS}, CAMERA_PERMISSION);
//
//                //requestPermissions 메소드는 비동기적으로 동작한다. 왜냐면 이 권한 검사 및 요청 메소드는
//                //메인 액티비티에서 동작하기떄문에(메인쓰레드) 사용자 반응성이 굉장히 중요한 파트이다. 여기서 시간을
//                //오래 끌어버리면 사람들이 답답함을 느끼게 된다. requestPermissions의 결과로 콜백 메소드인
//                //onRequestPermissionsResult()가 호출된다. 오버라이딩 메소드이다. Ctrl+O
//
//                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
//                // app-defined int constant. The callback method gets the
//                // result of the request.
//            }
//        }
//    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
//        if (requestCode == NUMBER_ORDER){
//            Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
//            startActivityForResult(intent, NUMBER_ORDER);
//        }
        if (resultCode == RESULT_OK) {
            Toast.makeText(getApplicationContext(), "취소", Toast.LENGTH_LONG).show();
        }
        if (resultCode == 1) { //result 코드로 확인버튼번호 1번이다
            try {
                String number = data.getStringExtra("menu_number"); //입력한값 string으로 도출
                if (number != null) {
                    int number_int = Integer.parseInt(number); //String 을 int로 변환
                    if (number_int == 1) { //number_int 가 1이면
                        Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                        startActivityForResult(intent, NUMBER_ORDER);
                    } else {
                        Toast.makeText(getApplicationContext(), "메뉴번호를 다시 입력해주세요", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "메뉴번호를 다시 입력해주세요", Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {

            }

        }

    }
// - -----------------메인액티비티 ------------코드------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("");
        actionBar.hide();
//        Permission_Check();
        deep_Link(); //딥링크 메소드

        AndPermission.with(this) //외부 라이브러리로 위험 권한 가져옴
                .runtime()
                .permission(
                        Permission.CAMERA,
                        Permission.READ_EXTERNAL_STORAGE,
                        Permission.WRITE_EXTERNAL_STORAGE)
                .start();

        ImageButton imagebutton = findViewById(R.id.imageButton); //카메라 버튼에 객체 생성
        imagebutton.setOnClickListener(new View.OnClickListener() { // 클릭리스너 장착
            public void onClick(View v) {
                OpenCamera(); //해당메소드
            }
        });

        ImageButton UseWifi = findViewById(R.id.imageButton3); //wifi버튼 에대한 객체생성
        UseWifi.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                WifiOption(); //해당메소드 참고
            }
        });
        Button button = findViewById(R.id.Order); //매장번호로 주문하기 버튼
        new android.os.Handler().postDelayed(new Runnable() { //버튼효과
            @Override
            public void run() {
                button.setEnabled(true);
            }
        }, 1000);
        button.setOnClickListener(new View.OnClickListener() { //컨텍스트로 액티비티연결
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), number_order.class);
                startActivityForResult(intent, NUMBER_ORDER);
            }
        });

        // 카메라 사용권한 추가

        //-------------------------------마이크 및 카메라 권한 -----------------------
        if ( Build.VERSION.SDK_INT >= 23 ){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.INTERNET, Manifest.permission.RECORD_AUDIO}, PERMISSION);
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA, Manifest.permission.CAMERA}, CAMERA_PERMISSION);
        }

        textView = findViewById(R.id.stt_textview);
        sttBtn = findViewById(R.id.imageButton4);

        intent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE,getPackageName());
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ko-KR");   // 텍스트로 변환시킬 언어 설정

        sttBtn.setOnClickListener(v -> {
            SpeechRecognizer mRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            mRecognizer.setRecognitionListener(listener);
            mRecognizer.startListening(intent);
        });


    }

    public void OpenCamera() { //메소드 내용
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE); //인텐트 생성후 카메라 앱사용
        startActivity(intent); //카메라앱사용 startActivitForResult 메소드는 반환값이 있어야함
    }

    public void WifiOption() { //wifi 버튼메소드
        Intent intent = new Intent(Settings.ACTION_WIFI_SETTINGS);
        startActivity(intent);
    }
    public void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private RecognitionListener listener = new RecognitionListener() {
        @Override
        public void onReadyForSpeech(Bundle params) {
            Toast.makeText(getApplicationContext(),"음성인식을 시작합니다.",Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onBeginningOfSpeech() {}

        @Override
        public void onRmsChanged(float rmsdB) {}

        @Override
        public void onBufferReceived(byte[] buffer) {}

        @Override
        public void onEndOfSpeech() {}

        @Override
        public void onError(int error) {
            String message;

            switch (error) {
                case SpeechRecognizer.ERROR_AUDIO:
                    message = "오디오 에러";
                    break;
                case SpeechRecognizer.ERROR_CLIENT:
                    message = "클라이언트 에러";
                    break;
                case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                    message = "퍼미션 없음";
                    break;
                case SpeechRecognizer.ERROR_NETWORK:
                    message = "네트워크 에러";
                    break;
                case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                    message = "네트웍 타임아웃";
                    break;
                case SpeechRecognizer.ERROR_NO_MATCH:
                    message = "찾을 수 없음";
                    break;
                case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                    message = "RECOGNIZER가 바쁨";
                    break;
                case SpeechRecognizer.ERROR_SERVER:
                    message = "서버가 이상함";
                    break;
                case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                    message = "말하는 시간초과";
                    break;
                default:
                    message = "알 수 없는 오류임";
                    break;
            }

            Toast.makeText(getApplicationContext(), "에러가 발생하였습니다. : " + message,Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onResults(Bundle results) {
            // 말을 하면 ArrayList에 단어를 넣고 textView에 단어를 이어준다.
            ArrayList<String> matches =
                    results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);

            for(int i = 0; i < matches.size() ; i++){
                textView.setText(matches.get(i));
            }
            String stt_text =textView.getText().toString();

            if (stt_text.equals("주문") || stt_text.equals("일") || stt_text.equals("1번")){
                Toast.makeText(getApplicationContext(), "주문페이지로 이동 ",Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                startActivityForResult(intent, NUMBER_ORDER);
            }else {
                Toast.makeText(getApplicationContext(), "발음을 정확히 하셔서 다시한번 말씀해주세요 ",Toast.LENGTH_LONG).show();
            }
        }

        @Override
        public void onPartialResults(Bundle partialResults) {}

        @Override
        public void onEvent(int eventType, Bundle params) {}


//        public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
//            switch (requestCode) {
//                case CAMERA_PERMISSION: {
//                    // If request is cancelled, the result arrays are empty.
//                    if (grantResults.length > 0
//                            && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//
//                        // permission was granted, yay! Do the
//                        // contacts-related task you need to do.
//
//                    } else {
//
//                        // permission denied, boo! Disable the
//                        // functionality that depends on this permission.
//                    }
//                    return;
//                }
//
//                // other 'case' lines to check for other
//                // permissions this app might request
//            }
//        }

    };

}