package org.techtown.test;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper_product extends SQLiteOpenHelper {
    public static String NAME = "Product.db";
    public static int VERSION = 1;

    public DatabaseHelper_product(Context context) {
        super(context, NAME, null, VERSION);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "create table if not exists Ordered_Product("
                + " _number integer PRIMARY KEY autoincrement, "
                + " name text, "
                + " amount integer, "
                + " price integer, "
                + " shot integer, "
                + " img integer, "
                + " ice integer)";

        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (newVersion > 1) {
            db.execSQL("DROP TABLE IF EXISTS Ordered_Product");
        }

        db.execSQL("DROP TABLE IF EXISTS Ordered_Product");
        onCreate(db);
    }

    public void UpdateDataBase(SQLiteDatabase db){
        String Table_name1 = "Ordered_Product";
        String Table_name2 = "Ordered_Product2";
        //DB2 생성
        String sql_create = "create table if not exists Ordered_Product2("
                + " _number integer PRIMARY KEY autoincrement, "
                + " name text, "
                + " amount integer, "
                + " price integer, "
                + " shot integer, "
                + " img integer, "
                + " ice integer)";

        db.execSQL(sql_create);


        //Table 1 조회 및 Table2 에삽입
        Cursor cursor = db.rawQuery("select _number, name, amount, price, shot, img, ice from Ordered_Product", null);
        int recordCount = cursor.getCount();

        for (int i = 0; i < recordCount; i++) {
            cursor.moveToNext();
            int number = cursor.getInt(0);
            String product_name = cursor.getString(1);
            int amount = cursor.getInt(2);
            int price = cursor.getInt(3);
            int shot = cursor.getInt(4);
            int img = cursor.getInt(5);
            int ice = cursor.getInt(6);

            String sql_insert = "insert into " + Table_name2 + "(name, amount, price, shot, img, ice) "
                    + " values "
                    + "('" + product_name + "', " + amount + ", " + price + ", " + shot + ", " + img + ", " + ice + ")";
            db.execSQL(sql_insert);
        }

        //Table 1 초기화
        db.execSQL("DROP TABLE IF EXISTS Ordered_Product");
        onCreate(db);

        //Table 2 조회 및 Table1 에삽입
        cursor = db.rawQuery("select _number, name, amount, price, shot, img, ice from Ordered_Product2", null);
        int recordCount2 = cursor.getCount();

        for (int i = 0; i < recordCount2; i++) {
            cursor.moveToNext();
            int number = cursor.getInt(0);
            String product_name = cursor.getString(1);
            int amount = cursor.getInt(2);
            int price = cursor.getInt(3);
            int shot = cursor.getInt(4);
            int img = cursor.getInt(5);
            int ice = cursor.getInt(6);

            String sql_insert = "insert into " + Table_name1 + "(name, amount, price, shot, img, ice) "
                    + " values "
                    + "('" + product_name + "', " + amount + ", " + price + ", " + shot + ", " + img + ", " + ice + ")";
            db.execSQL(sql_insert);
        }
        //Table 2 삭제
        db.execSQL("DROP TABLE IF EXISTS Ordered_Product2");

    }
}
