package org.techtown.test;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MenuActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ProductAdapter adapter;
    public static final int pay = 103;

    //데이터베이스
    DatabaseHelper_product dbHelper;
    DatabaseHelper_order dbHelper2;
    SQLiteDatabase database;
    SQLiteDatabase database_order;

    String tableName = "Ordered_Product";
    String tableName2 = "index_product";


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
        createDatabase();
        Cursor cursor = database.rawQuery("select _number, name, amount, price, shot, img, ice from Ordered_Product", null);
        int recordCount = cursor.getCount();


        //객체 리스트화 시켜서
        ArrayList<Product> beverage2 = new ArrayList<Product>();
        beverage2.add(new Product("음료수1", "스타벅스", 2000, R.drawable.strawberry));
        beverage2.add(new Product("음료수2", "스타벅스", 3000, R.drawable.mango_banana));
        beverage2.add(new Product("음료수3", "스타벅스", 4000, R.drawable.mango_fruit));


        Button button = findViewById(R.id.button6); //결제하기 버튼 객체 생성
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent intent = new Intent(getApplicationContext(), paypage.class);
//                startActivityForResult(intent, pay);

                Intent intent = new Intent(getApplicationContext(), Order_index.class);
                startActivity(intent);
            }
        });

        recyclerView = findViewById(R.id.recycleView);

        GridLayoutManager layoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(layoutManager);

        adapter = new ProductAdapter();

        adapter.addItem(new Product("망고 패션 프루트 블랜디드", "스타벅스", 5500, R.drawable.mango_fruit));
        adapter.addItem(new Product("딸기 딜라이트 요거트 블랜디드", "스타벅스", 5700, R.drawable.strawberry));
        adapter.addItem(new Product("망고 바나나 블랜디드", "스타벅스", 5300, R.drawable.mango_banana));
        adapter.addItem(new Product("제주 감귤 당근 스노잉 블랜디드", "스타벅스", 5500, R.drawable.jeju));

        recyclerView.setAdapter(adapter);


        Button blended = findViewById(R.id.blended); //전체버튼
        blended.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adapter.init_item();

                for(int i=0; i< beverage2.size(); i++)
                {
                    adapter.addItem(beverage2.get(i));
                }

                recyclerView.setAdapter(adapter);

            }
        });


        adapter.setOnItemClickListener(new OnProductItemClickListener() {
            @Override
            public void onItemClick(ProductAdapter.ViewHolder holder, View view, int position) {
                Product item = adapter.getItem(position);
                if(item.getPrice() > 0){
                    Intent intent = new Intent(getApplicationContext(), productselect.class);
                    intent.putExtra("name", item.getName());
                    intent.putExtra("price", Integer.toString(item.getPrice()));
                    intent.putExtra("photo", Integer.toString(item.getImageRes()));
                    intent.putExtra("manufacturer", item.getManufacturer());
                    startActivity(intent);
                }

            }
        });

        FloatingActionButton fab = findViewById(R.id.fab_btn); //데이터 베이스 활용하기
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                createDatabase();
//                Cursor cursor = database.rawQuery("select _number, name, amount, price, shot, img, ice from Ordered_Product", null);
//                int recordCount = cursor.getCount();
//
//                for (int i = 0; i < recordCount; i++) {
//                    cursor.moveToNext();
//                    int number = cursor.getInt(0);
//                    String product_name = cursor.getString(1);
//                    int amount = cursor.getInt(2);
//                    int price = cursor.getInt(3);
//                    int shot = cursor.getInt(4);
//                    int img = cursor.getInt(5);
//                    int ice = cursor.getInt(6);
//                    Toast.makeText(getApplicationContext(), product_name, Toast.LENGTH_SHORT).show();
//                }
                Intent intent = new Intent(getApplicationContext(), Order_index.class);
                startActivity(intent);
            }
        });

        if (recordCount > 0){
            button.setText("결제하기" + " ( " + recordCount + " )");
            button.setBackgroundColor(Color.parseColor("#4169E1"));

        }

    }
    public void createDatabase(){
        dbHelper = new DatabaseHelper_product(this);
        database = dbHelper.getWritableDatabase();
    }


    @Override
    protected void onRestart() {
        super.onRestart();

        finish();//인텐트 종료
        overridePendingTransition(0, 0);//인텐트 효과 없애기
        Intent intent = getIntent(); //인텐트
        startActivity(intent); //액티비티 열기
        overridePendingTransition(0, 0);//인텐트 효과 없애기
    }
}