package org.techtown.test;

import android.view.View;

public interface ResultAdapterListener {
    public void onItemClick(ResultAdapter.ViewHolder holder, View view, int position);
}
