package org.techtown.test;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class productselect extends AppCompatActivity {
    int img;
    String total; //상품선택할때 전체가격
    int amount; // 상품수량
    int price2; // 상품가격
    int shot = 0; // 샷
    boolean ice = true; // 얼음 유무
    int ice_int;
    public static final int order = 2000; //확인버튼 눌럿을때 반환값

    DatabaseHelper_product dbHelper;
    SQLiteDatabase database;

    String tableName = "Ordered_Product";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productselect);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();




        Intent intent = getIntent();
        ice_effect();

        ImageView photo = (ImageView) findViewById(R.id.product_image);
        TextView name = (TextView) findViewById(R.id.name);
        TextView price = (TextView) findViewById(R.id.price);
        String manufacturer = intent.getStringExtra("manufacturer");

        img = Integer.parseInt(intent.getStringExtra("photo"));
        photo.setImageResource(img);
        name.setText(intent.getStringExtra("name"));
        String product_name = intent.getStringExtra("name");

        price.setText(intent.getStringExtra("price"));

        //수량
        TextView count2 = findViewById(R.id.count2);
        amount = Integer.parseInt(count2.getText().toString());
        //가격
        price2 = Integer.parseInt(price.getText().toString());
        //합계
        total = Integer.toString(amount * price2 );

        TextView result = findViewById(R.id.result);
        result.setText(total);

        //plus and minus button 수량
        ImageButton plus1 = findViewById(R.id.plus1);
        plus1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView count2 = findViewById(R.id.count2);
                amount++;
                count2.setText(Integer.toString(amount));
                total = Integer.toString(amount * price2 );
                TextView result = findViewById(R.id.result);
                result.setText(total);

            }
        });
        ImageButton minus1 = findViewById(R.id.minus1);
        minus1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView count2 = findViewById(R.id.count2);
                if(amount > 1){
                    amount--;
                    count2.setText(Integer.toString(amount));
                    total = Integer.toString(amount * price2 );
                    TextView result = findViewById(R.id.result);
                    result.setText(total);
                }else{
                    Toast.makeText(getApplicationContext(), "1 이하로는 할 수 없습니다", Toast.LENGTH_SHORT).show();
                }

            }
        });
        // plus minus button 샷추가
        ImageButton plus2 = findViewById(R.id.plus2);
        plus2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                shot++;
                shot_text_set();
            }
        });
        ImageButton minus2 = findViewById(R.id.minus2);
        minus2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                shot--;
                shot_text_set();
            }
        });

        //얼음 on / off
        Button on = findViewById(R.id.on);
        Button off = findViewById(R.id.off);
        on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ice = true;
                ice_int = 1;
                ice_effect();
            }
        });
        off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ice = false;
                ice_int = 0;
                ice_effect();
            }
        });

        //확인 버튼
        Button Ok_button = findViewById(R.id.ok);
        Ok_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(getApplicationContext(), MenuActivity.class);
                createDatabase();
                createTable();



//                Toast.makeText(productselect.this, "ice : " + ice + " ice_int " + ice_int + product_name , Toast.LENGTH_SHORT).show();
                String sql = "insert into " + tableName + "(name, amount, price, shot, img, ice) "
                        + " values "
                        + "('" + product_name + "', " + amount + ", " + price2 + ", " + shot + ", " + img + ", " + ice_int + ")";
                database.execSQL(sql);

                Cursor cursor = database.rawQuery("select _number, name, amount, price, shot, img, ice from Ordered_Product", null);
                int recordCount = cursor.getCount();

                for (int i = 0; i < recordCount; i++){
                    cursor.moveToNext();
                    int number = cursor.getInt(0);
                    String product_name = cursor.getString(1);
                    int amount = cursor.getInt(2);
                    int price = cursor.getInt(3);
                    int shot = cursor.getInt(4);
                    int img = cursor.getInt(5);
                    int ice = cursor.getInt(6);
                    Toast.makeText(getApplicationContext(), product_name , Toast.LENGTH_SHORT).show();
                }

                cursor.close();

                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent2);
                Toast.makeText(getApplicationContext(), "구매상품에 추가되셧습니다", Toast.LENGTH_SHORT).show();
            }
        });
        // 취소버튼
        Button cancel_button = findViewById(R.id.cancel);
        cancel_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(getApplicationContext(), MenuActivity.class);
                intent2.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent2);
                Toast.makeText(getApplicationContext(), "취소", Toast.LENGTH_SHORT).show();

                setResult(order,intent2);
                finish();
            }
        });
    }
    public void shot_text_set(){
        TextView count3 = findViewById(R.id.count3); // 샷추가
        String none_shot = "없음";
        if (shot > 0){
            count3.setText(Integer.toString(shot));
        }else{
            count3.setText(none_shot);
        }
    }

    public void ice_effect(){ //얼음 있으면 효과줌
        Button on = findViewById(R.id.on);
        Button off = findViewById(R.id.off);

        if (ice == true){
            on.setBackgroundColor(Color.CYAN);
            off.setBackgroundColor(0);
        }else {
            off.setBackgroundColor(Color.RED);
            on.setBackgroundColor(0);
        }
    }

    public void createDatabase(){
        dbHelper = new DatabaseHelper_product(this);
        database = dbHelper.getWritableDatabase();
    }

    public void createTable(){
        database.execSQL("create table if not exists "+ tableName +"("
                + " _number integer PRIMARY KEY autoincrement, "
                + " name text, "
                + " amount integer, "
                + " price integer, "
                + " shot integer, "
                + " ice integer)");
    }
/*
    public void executeQuery() {
        Cursor cursor = database.rawQuery("select _number, name, amount, price, shot, img, ice from Ordered_Product", null);
        int recordCount = cursor.getCount();

        for (int i = 0; i < recordCount; i++){
            cursor.moveToNext();
            int number = cursor.getInt(0);
            String product_name = cursor.getString(1);
            int amount = cursor.getInt(2);
            int price = cursor.getInt(3);
            int shot = cursor.getInt(4);
            int img = cursor.getInt(5);
            int ice = cursor.getInt(6);
        }

        cursor.close();
    }
*/
}