package org.techtown.test;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class number_order extends AppCompatActivity {
    public static final int MENU = 1; //메뉴에 접근


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_number_order);
        try {
            ActionBar actionBar = getSupportActionBar();
            actionBar.hide();
        } catch (Exception e){

        }
        Button button3 = findViewById(R.id.button3); //확인버튼
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                EditText url = findViewById(R.id.url);
                String value = url.getText().toString();
                intent.putExtra("menu_number",value);
                setResult(MENU, intent);
                finish();

            }
        });
        Button button4 = findViewById(R.id.button4); //취소버튼
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                EditText url = findViewById(R.id.url);
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }
}